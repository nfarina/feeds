//
//  SR_Leopard.h
//  SR Leopard
//
//  Created by Jesper on 2007-10-19.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface SR_Leopard : IBPlugin {
}

@end
